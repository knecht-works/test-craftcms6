-- MySQL dump 10.13  Distrib 8.4.5, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.4.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activityevents`
--

DROP TABLE IF EXISTS `activityevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activityevents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `eventType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actorType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actorId` bigint unsigned DEFAULT NULL,
  `subjectType` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `siteId` bigint unsigned DEFAULT NULL,
  `rootEventId` bigint unsigned DEFAULT NULL,
  `payload` json NOT NULL,
  `occurredAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_6e78564a98f18121166682e3ab27abeb` (`actorType`,`actorId`),
  KEY `idx_66c23d5024b4325b6e661b5b02329a01` (`subjectType`,`subjectId`,`siteId`,`occurredAt`,`id`),
  KEY `idx_0052ab68a2ba811b07dadf20988d2655` (`occurredAt`,`id`),
  KEY `idx_1fab199aa1ec6c45a35dcb80181607c5` (`rootEventId`,`occurredAt`,`id`),
  CONSTRAINT `activityevents_rooteventid_foreign` FOREIGN KEY (`rootEventId`) REFERENCES `activityevents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activityevents`
--

LOCK TABLES `activityevents` WRITE;
/*!40000 ALTER TABLE `activityevents` DISABLE KEYS */;
INSERT INTO `activityevents` VALUES (1,'CraftCms\\Cms\\Activity\\EventTypes\\ElementCreated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','0bae9266-7360-4aa4-a10c-94261c7a5a5c',2,NULL,'{\"data\": {}, \"changes\": [], \"snapshots\": {\"site\": {\"name\": \"DE\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Created\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"Home\"}}}','2026-10-07 08:25:28'),(2,'CraftCms\\Cms\\Activity\\EventTypes\\ElementCreated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','0bae9266-7360-4aa4-a10c-94261c7a5a5c',3,NULL,'{\"data\": {}, \"changes\": [], \"snapshots\": {\"site\": {\"name\": \"GB\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Created\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"Home\"}}}','2026-10-07 08:25:28'),(3,'CraftCms\\Cms\\Activity\\EventTypes\\ElementCreated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','0bae9266-7360-4aa4-a10c-94261c7a5a5c',1,NULL,'{\"data\": {}, \"changes\": [], \"snapshots\": {\"site\": {\"name\": \"EN\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Created\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"Home\"}}}','2026-10-07 08:25:28'),(4,'CraftCms\\Cms\\Activity\\EventTypes\\ElementUpdated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','0bae9266-7360-4aa4-a10c-94261c7a5a5c',1,NULL,'{\"data\": {}, \"changes\": [{\"new\": \"(EN) Boot. Fix. Test. Fully automatic.\", \"old\": null, \"label\": \"Headline\"}, {\"new\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"old\": null, \"label\": \"Intro Text\"}, {\"new\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\", \"old\": null, \"label\": \"Content\"}], \"snapshots\": {\"site\": {\"name\": \"EN\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Updated\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"Home\"}}}','2026-10-07 01:27:49'),(5,'CraftCms\\Cms\\Activity\\EventTypes\\ElementUpdated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','0bae9266-7360-4aa4-a10c-94261c7a5a5c',2,NULL,'{\"data\": {}, \"changes\": [{\"new\": \"(DE) Booten. Fixen. Testen. Vollautomatisch.\", \"old\": null, \"label\": \"Headline\"}, {\"new\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"old\": null, \"label\": \"Intro Text\"}, {\"new\": \"Knecht startet dein DDEV-Setup als komplette Umgebung, inklusive Web, Services und Datenbank. Jedes Projekt enthält alle Informationen, die es für einen vollständigen Boot braucht.\", \"old\": null, \"label\": \"Content\"}], \"snapshots\": {\"site\": {\"name\": \"DE\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Updated\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"Home\"}}}','2026-10-07 01:27:49'),(6,'CraftCms\\Cms\\Activity\\EventTypes\\ElementUpdated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','0bae9266-7360-4aa4-a10c-94261c7a5a5c',3,NULL,'{\"data\": {}, \"changes\": [{\"new\": \"(GB) Boot. Fix. Test. Fully automatic.\", \"old\": null, \"label\": \"Headline\"}, {\"new\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"old\": null, \"label\": \"Intro Text\"}, {\"new\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\", \"old\": null, \"label\": \"Content\"}], \"snapshots\": {\"site\": {\"name\": \"GB\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Updated\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"Home\"}}}','2026-10-07 01:27:49'),(7,'CraftCms\\Cms\\Activity\\EventTypes\\ElementCreated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','a73bb0a4-6de4-4e6b-af23-28159f7a429c',2,NULL,'{\"data\": {}, \"changes\": [], \"snapshots\": {\"site\": {\"name\": \"DE\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Created\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"News\"}}}','2026-10-07 01:27:49'),(8,'CraftCms\\Cms\\Activity\\EventTypes\\ElementCreated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','a73bb0a4-6de4-4e6b-af23-28159f7a429c',3,NULL,'{\"data\": {}, \"changes\": [], \"snapshots\": {\"site\": {\"name\": \"GB\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Created\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"News\"}}}','2026-10-07 01:27:49'),(9,'CraftCms\\Cms\\Activity\\EventTypes\\ElementCreated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','a73bb0a4-6de4-4e6b-af23-28159f7a429c',1,NULL,'{\"data\": {}, \"changes\": [], \"snapshots\": {\"site\": {\"name\": \"EN\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Created\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"News\"}}}','2026-10-07 01:27:49'),(10,'CraftCms\\Cms\\Activity\\EventTypes\\ElementUpdated','craft','system',NULL,'CraftCms\\Cms\\Entry\\Elements\\Entry','a73bb0a4-6de4-4e6b-af23-28159f7a429c',2,NULL,'{\"data\": {}, \"changes\": [{\"new\": \"Booten. Fixen. Testen. Vollautomatisch.\", \"old\": \"Get Updates from Knecht Works\", \"label\": \"Headline\"}, {\"new\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"old\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"label\": \"Intro Text\"}, {\"new\": \"Laufende Betreuung heißt Updates einspielen, Bugs reproduzieren, alles testen. Knecht macht daraus Workflows, die immer gleich ablaufen, und holt AI nur da rein, wo sie wirklich hilft.\", \"old\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\", \"label\": \"Content\"}], \"snapshots\": {\"site\": {\"name\": \"DE\"}, \"actor\": {\"label\": \"Craft CMS\"}, \"event\": {\"label\": \"Updated\"}, \"source\": {\"label\": \"Craft\"}, \"subject\": {\"label\": \"News\"}}}','2026-10-07 01:27:49');
/*!40000 ALTER TABLE `activityevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `administrativeArea` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dependentLocality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortingCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organizationTaxId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fullName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_primaryownerid_foreign` (`primaryOwnerId`),
  CONSTRAINT `addresses_id_foreign` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_primaryownerid_foreign` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text COLLATE utf8mb4_unicode_ci,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eeee25992290bfc36b03d39f38ddadd1` (`sessionId`,`volumeId`),
  KEY `idx_daa4b55f6facafc13d40be80ae35c9a8` (`sessionId`,`status`,`id`),
  KEY `idx_c7e802d6fc28ca5cf44d5974bb9de361` (`volumeId`),
  CONSTRAINT `assetindexdata_sessionid_foreign` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assetindexdata_volumeid_foreign` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text COLLATE utf8mb4_unicode_ci,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mimeType` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kind` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `colors` json DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_1433507e5ddf137779638037389a339b` (`filename`,`folderId`),
  KEY `idx_f8fe5ade69bef3082d6fb5d1e5091409` (`folderId`),
  KEY `idx_1ca11fba46d7b113a89c86ab4832b6c4` (`volumeId`),
  KEY `assets_uploaderid_foreign` (`uploaderId`),
  CONSTRAINT `assets_folderid_foreign` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_foreign` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_uploaderid_foreign` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assets_volumeid_foreign` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (4,1,1,NULL,'dashboard.png','image/png','image',1572,1045,286966,NULL,'{\"grid\": [[\"#1e1d1d\", \"#161817\", \"#141a13\", \"#1f291d\"], [\"#141515\", \"#111111\", \"#0b0b0b\", \"#0b0b0c\"], [\"#131314\", \"#111211\", \"#0e0f0e\", \"#0b0b0c\"]], \"dominant\": \"#1f231f\"}',NULL,NULL,'2026-10-07 08:27:30','2026-10-07 01:27:31','2026-10-07 01:27:31');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `assets_sites_siteid_foreign` (`siteId`),
  CONSTRAINT `assets_sites_assetid_foreign` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_sites_siteid_foreign` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
INSERT INTO `assets_sites` VALUES (4,1,NULL),(4,2,NULL),(4,3,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `authenticator_userid_foreign` (`userId`),
  CONSTRAINT `authenticator_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senderClass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_5d6f9efbe3a64be90bb0d351c292a842` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_48f60433a6f18529a572ba707d3a24ec` (`elementId`,`siteId`,`dateUpdated`),
  KEY `changedattributes_siteid_foreign` (`siteId`),
  KEY `changedattributes_userid_foreign` (`userId`),
  CONSTRAINT `changedattributes_elementid_foreign` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedattributes_siteid_foreign` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedattributes_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (1,1,'lastPasswordChangeDate','2026-10-07 04:36:01',0,NULL),(1,1,'password','2026-10-07 04:36:01',0,NULL),(3,1,'expiryDate','2026-10-07 08:25:28',0,NULL),(3,1,'fieldId','2026-10-07 08:25:28',0,NULL),(3,1,'id','2026-10-07 08:25:28',0,NULL),(3,1,'postDate','2026-10-07 08:25:28',0,NULL),(3,1,'primaryOwnerId','2026-10-07 08:25:28',0,NULL),(3,1,'sectionId','2026-10-07 08:25:28',0,NULL),(3,1,'status','2026-10-07 08:25:28',0,NULL),(3,1,'title','2026-10-07 08:25:28',0,NULL),(3,1,'typeId','2026-10-07 08:25:28',0,NULL),(9,1,'expiryDate','2026-10-07 01:27:49',0,NULL),(9,1,'fieldId','2026-10-07 01:27:49',0,NULL),(9,1,'id','2026-10-07 01:27:49',0,NULL),(9,1,'postDate','2026-10-07 01:27:49',0,NULL),(9,1,'primaryOwnerId','2026-10-07 01:27:49',0,NULL),(9,1,'sectionId','2026-10-07 01:27:49',0,NULL),(9,1,'status','2026-10-07 01:27:49',0,NULL),(9,1,'title','2026-10-07 01:27:49',0,NULL),(9,1,'typeId','2026-10-07 01:27:49',0,NULL);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_75a65e36cbb04e65d1a56cbc14b28da7` (`elementId`,`siteId`,`dateUpdated`),
  KEY `changedfields_siteid_foreign` (`siteId`),
  KEY `changedfields_fieldid_foreign` (`fieldId`),
  KEY `changedfields_userid_foreign` (`userId`),
  CONSTRAINT `changedfields_elementid_foreign` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedfields_fieldid_foreign` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedfields_siteid_foreign` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedfields_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (2,1,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',1,NULL),(2,1,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',1,NULL),(2,1,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',1,NULL),(2,1,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',1,NULL),(2,2,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',1,NULL),(2,2,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',1,NULL),(2,2,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',1,NULL),(2,2,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',1,NULL),(2,3,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',0,NULL),(2,3,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',0,NULL),(2,3,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',0,NULL),(2,3,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',0,NULL),(3,1,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 08:25:28',0,NULL),(3,1,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 08:25:28',0,NULL),(3,1,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 08:25:28',0,NULL),(3,1,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 08:25:28',0,NULL),(5,1,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',0,NULL),(5,1,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',0,NULL),(5,1,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',0,NULL),(5,1,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',0,NULL),(6,2,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',0,NULL),(6,2,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',0,NULL),(6,2,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',0,NULL),(6,2,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',0,NULL),(7,3,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',0,NULL),(7,3,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',0,NULL),(7,3,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',0,NULL),(7,3,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',0,NULL),(8,1,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:50',1,NULL),(8,1,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:50',1,NULL),(8,1,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:50',1,NULL),(8,1,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:50',1,NULL),(8,2,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:50',1,NULL),(8,2,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:50',1,NULL),(8,2,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:50',1,NULL),(8,2,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:50',1,NULL),(8,3,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:50',0,NULL),(8,3,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:50',0,NULL),(8,3,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:50',0,NULL),(8,3,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:50',0,NULL),(9,1,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',0,NULL),(9,1,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',0,NULL),(9,1,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',0,NULL),(9,1,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',0,NULL),(10,2,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:49',0,NULL),(10,2,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:49',0,NULL),(10,2,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:49',0,NULL),(10,2,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:49',0,NULL),(11,3,1,'391b8f8f-308d-4090-b42d-c700f95e63e5','2026-10-07 01:27:50',0,NULL),(11,3,2,'2b90f4d4-ffff-45d4-b352-8157b56cceb1','2026-10-07 01:27:50',0,NULL),(11,3,3,'0f2ccff6-e12e-4bf5-b550-f79c3698e43f','2026-10-07 01:27:50',0,NULL),(11,3,4,'4d5f9302-a0dc-48ab-b58d-e36ffd1c82df','2026-10-07 01:27:50',0,NULL);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contentblocks`
--

DROP TABLE IF EXISTS `contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contentblocks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_5b33c0a520ab0403d9edafb5192d6b53` (`primaryOwnerId`),
  KEY `idx_5e4bc233b2e7c743b739dfc813c13ab1` (`fieldId`),
  CONSTRAINT `contentblocks_fieldid_foreign` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contentblocks_id_foreign` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contentblocks_primaryownerid_foreign` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contentblocks`
--

LOCK TABLES `contentblocks` WRITE;
/*!40000 ALTER TABLE `contentblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `contentblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_23842f84536530d5fa3d8708771c6ca8` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_08a4f3be25e8505a908b1665fa138c0c` (`creatorId`,`provisional`),
  KEY `idx_8232272ee9cea724ae9ba5ec679b3ad6` (`saved`),
  KEY `drafts_canonicalid_foreign` (`canonicalId`),
  CONSTRAINT `drafts_canonicalid_foreign` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `drafts_creatorid_foreign` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_6588eec70fc50d8ebba68c3f8d28c1a5` (`elementId`,`timestamp`,`userId`),
  KEY `elementactivity_userid_foreign` (`userId`),
  KEY `elementactivity_siteid_foreign` (`siteId`),
  CONSTRAINT `elementactivity_elementid_foreign` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elementactivity_siteid_foreign` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elementactivity_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_517f1eacccb2c1de3037b807b7ebe50c` (`dateDeleted`),
  KEY `idx_65fb5ccf81fdcb361a0d42ca1db89140` (`fieldLayoutId`),
  KEY `idx_d9f94241e7e8299581446aaef9f3ff6a` (`type`),
  KEY `idx_185ee21c8b87def48abe60e484ec7dcc` (`enabled`),
  KEY `idx_0d942525942cf103f06a80924f762d29` (`canonicalId`,`dateCreated`),
  KEY `idx_6ef0423a475c077ae2ceee0d5ce003d1` (`archived`,`dateCreated`),
  KEY `idx_f16ef0a772296f5e862415f3afdc9912` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_fa5918b49d7a06205bb1ed0a1ddc4a95` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `elements_draftid_foreign` (`draftId`),
  KEY `elements_revisionid_foreign` (`revisionId`),
  CONSTRAINT `elements_canonicalid_foreign` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `elements_draftid_foreign` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_fieldlayoutid_foreign` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `elements_revisionid_foreign` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'CraftCms\\Cms\\User\\Elements\\User',1,0,'2026-10-07 08:17:22','2026-10-07 11:36:00',NULL,NULL,NULL,'8a1ac1d3-c2cd-4c1e-ba49-bbf444a7a4a1'),(2,NULL,NULL,NULL,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:25:28','2026-10-07 08:27:49',NULL,NULL,NULL,'0bae9266-7360-4aa4-a10c-94261c7a5a5c'),(3,2,NULL,1,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,NULL,NULL,'a6145e63-62f7-4dc3-bd07-74fba2c7f460'),(4,NULL,NULL,NULL,1,'CraftCms\\Cms\\Asset\\Elements\\Asset',1,0,'2026-10-07 08:27:31','2026-10-07 08:27:31',NULL,NULL,NULL,'ee006a89-a878-4d02-814e-8953fe6e7f1b'),(5,2,NULL,2,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:27:49','2026-10-07 08:27:49',NULL,NULL,NULL,'9cb95a22-b015-4e99-bae4-9283d9fdba22'),(6,2,NULL,3,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:27:49','2026-10-07 08:27:49',NULL,NULL,NULL,'d61f15de-313c-4b87-8c0c-69571bf4020b'),(7,2,NULL,4,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:27:49','2026-10-07 08:27:49',NULL,NULL,NULL,'b32ccc9a-6941-4082-907f-e007c66c0e01'),(8,NULL,NULL,NULL,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:27:49','2026-10-07 08:27:49',NULL,NULL,NULL,'a73bb0a4-6de4-4e6b-af23-28159f7a429c'),(9,8,NULL,5,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:27:49','2026-10-07 08:27:49',NULL,NULL,NULL,'58d8a0d6-8292-445e-9bff-2a3b3dd8ed58'),(10,8,NULL,6,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:27:49','2026-10-07 08:27:49',NULL,NULL,NULL,'cd0046c1-2271-4015-a049-26eb87a41b3e'),(11,8,NULL,7,2,'CraftCms\\Cms\\Entry\\Elements\\Entry',1,0,'2026-10-07 08:27:49','2026-10-07 08:27:50',NULL,NULL,NULL,'e448885f-9971-4963-838f-de83f88cfff7');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_b8424fc8e71930cf9e3c751dc1217873` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `idx_656e2ad09d85b748ee51de0b64aac595` (`ownerId`),
  KEY `idx_63aa8bad2bb1687877f89aad95f79058` (`sortOrder`),
  CONSTRAINT `elements_owners_elementid_foreign` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_owners_ownerid_foreign` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_6e84b6fec520735e9dcdb08e3c15e2ab` (`elementId`,`siteId`),
  KEY `idx_09785863da800197f2d3057e8894915d` (`siteId`),
  KEY `idx_f5260a0dae79e3993e61e20f66e37aaf` (`title`,`siteId`),
  KEY `idx_856a1d1f27528dbe789391f3a523e1b4` (`slug`,`siteId`),
  KEY `idx_a8c104e62e4eceb3527293916d724a7b` (`enabled`),
  KEY `idx_4852127eb50f52a81f5e708581e8ad5f` (`uri`,`siteId`),
  CONSTRAINT `elements_sites_elementid_foreign` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteid_foreign` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2026-10-07 08:17:22','2026-10-07 08:17:22','0'),(2,2,1,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(EN) Boot. Fix. Test. Fully automatic.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\"}',1,'2026-10-07 08:25:28','2026-10-07 01:27:49','0'),(3,2,2,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(DE) Booten. Fixen. Testen. Vollautomatisch.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Knecht startet dein DDEV-Setup als komplette Umgebung, inklusive Web, Services und Datenbank. Jedes Projekt enthält alle Informationen, die es für einen vollständigen Boot braucht.\"}',1,'2026-10-07 08:25:28','2026-10-07 01:27:49','0'),(4,2,3,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(GB) Boot. Fix. Test. Fully automatic.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\"}',1,'2026-10-07 08:25:28','2026-10-07 01:27:49','0'),(5,3,1,'Home','home','__home__',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','0'),(6,3,2,'Home','home','__home__',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','0'),(7,3,3,'Home','home','__home__',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','0'),(8,4,1,'Dashboard',NULL,NULL,NULL,1,'2026-10-07 01:27:31','2026-10-07 01:27:31','0'),(9,4,2,'Dashboard',NULL,NULL,NULL,1,'2026-10-07 01:27:31','2026-10-07 01:27:31','0'),(10,4,3,'Dashboard',NULL,NULL,NULL,1,'2026-10-07 01:27:31','2026-10-07 01:27:31','0'),(11,5,1,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(EN) Boot. Fix. Test. Fully automatic.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(12,5,2,'Home','home','__home__','{\"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4]}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(13,5,3,'Home','home','__home__','{\"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4]}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(14,6,2,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(DE) Booten. Fixen. Testen. Vollautomatisch.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Knecht startet dein DDEV-Setup als komplette Umgebung, inklusive Web, Services und Datenbank. Jedes Projekt enthält alle Informationen, die es für einen vollständigen Boot braucht.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(15,6,1,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(EN) Boot. Fix. Test. Fully automatic.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(16,6,3,'Home','home','__home__','{\"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4]}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(17,7,3,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(GB) Boot. Fix. Test. Fully automatic.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(18,7,1,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht boots every DDEV project as a fully running environment so AI agents can test against the real app, find bugs, and fix them.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(EN) Boot. Fix. Test. Fully automatic.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"A self-hostable orchestration tool for agencies that maintain many projects at once. Knecht connects to your GitHub repos, boots a complete running environment with one click, and lets AI agents fix bugs, run tests, and deliver finished pull requests.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(19,7,2,'Home','home','__home__','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"(DE) Booten. Fixen. Testen. Vollautomatisch.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Knecht startet dein DDEV-Setup als komplette Umgebung, inklusive Web, Services und Datenbank. Jedes Projekt enthält alle Informationen, die es für einen vollständigen Boot braucht.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(20,8,1,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(21,8,2,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Booten. Fixen. Testen. Vollautomatisch.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Laufende Betreuung heißt Updates einspielen, Bugs reproduzieren, alles testen. Knecht macht daraus Workflows, die immer gleich ablaufen, und holt AI nur da rein, wo sie wirklich hilft.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:50','0'),(22,8,3,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(23,9,1,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(24,9,2,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(25,9,3,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(26,10,2,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Booten. Fixen. Testen. Vollautomatisch.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Laufende Betreuung heißt Updates einspielen, Bugs reproduzieren, alles testen. Knecht macht daraus Workflows, die immer gleich ablaufen, und holt AI nur da rein, wo sie wirklich hilft.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(27,10,1,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(28,10,3,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:49','2026-10-07 01:27:49','0'),(29,11,3,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:50','2026-10-07 01:27:50','0'),(30,11,1,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"I\'m baby brooklyn shakshuka claire saffitz poke tumblr miso ayahuasca crochet portra heirloom pinterest.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Get Updates from Knecht Works\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Vape unicorn stumptown tahini photo booth. Situationship offill PBR&B gravel bike, skateboard robert walser blundstones marfa open studio. Tumeric iykyk braun dirtbag, lynch tacos pug. Shaman vegan recession indicator, banjo pok pok jade roller selfies synth somatic sufjan occupy master cleanse moon phase. Plaid ashwagandha gatekeep pork belly garum chillwave wolf cut vice disrupt affogato band tee. Succulents shrub snackwave mushroom coffee. Red light therapy mate japanese breakfast lacto-ferment master cleanse occupy kettlebell before they sold out gravel bike in this economy.\"}',1,'2026-10-07 01:27:50','2026-10-07 01:27:50','0'),(31,11,2,'News','news','news','{\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\": \"Knecht ist ein Dashboard auf deinem Server, gebaut für Agenturen mit vielen DDEV-Projekten. Er bootet jedes Projekt als komplett lauffähige Umgebung, erledigt Aufgaben und liefert fertige Pull Requests mit Preview.\", \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\": [4], \"391b8f8f-308d-4090-b42d-c700f95e63e5\": \"Booten. Fixen. Testen. Vollautomatisch.\", \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\": \"Laufende Betreuung heißt Updates einspielen, Bugs reproduzieren, alles testen. Knecht macht daraus Workflows, die immer gleich ablaufen, und holt AI nur da rein, wo sie wirklich hilft.\"}',1,'2026-10-07 01:27:50','2026-10-07 01:27:50','0');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dc81c96c31e32bb5697d128623707d5f` (`postDate`),
  KEY `idx_4d4699a9b616ba553c61f2a6cb472966` (`expiryDate`),
  KEY `idx_ea81e6ee844ca431ac458868b48045de` (`status`),
  KEY `idx_1daf43d94d257b5aae882c44c7c999de` (`sectionId`,`postDate`),
  KEY `idx_e2ac3a8ac77cd8ceea9a85953d9acea1` (`typeId`),
  KEY `idx_1212713667020114c00dde549e0a4065` (`primaryOwnerId`),
  KEY `idx_e6c5212e3b2d148187be21d9b96ab9bd` (`fieldId`),
  KEY `entries_parentid_foreign` (`parentId`),
  CONSTRAINT `entries_fieldid_foreign` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_foreign` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_parentid_foreign` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entries_primaryownerid_foreign` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_sectionid_foreign` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeid_foreign` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2026-10-07 08:25:28',NULL,'live',NULL,NULL,'2026-10-07 08:25:28','2026-10-07 08:25:28'),(3,1,NULL,NULL,NULL,1,'2026-10-07 08:25:28',NULL,'live',NULL,NULL,'2026-10-07 08:25:28','2026-10-07 08:25:28'),(5,1,NULL,NULL,NULL,1,'2026-10-07 08:25:28',NULL,'live',NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),(6,1,NULL,NULL,NULL,1,'2026-10-07 08:25:28',NULL,'live',NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),(7,1,NULL,NULL,NULL,1,'2026-10-07 08:25:28',NULL,'live',NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),(8,2,NULL,NULL,NULL,1,'2026-10-07 08:27:00',NULL,'live',NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),(9,2,NULL,NULL,NULL,1,'2026-10-07 08:27:00',NULL,'live',NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),(10,2,NULL,NULL,NULL,1,'2026-10-07 08:27:00',NULL,'live',NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),(11,2,NULL,NULL,NULL,1,'2026-10-07 08:27:00',NULL,'live',NULL,NULL,'2026-10-07 01:27:50','2026-10-07 01:27:50');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_d4db5906f8b5fa570b4485c4ad020ebf` (`authorId`),
  KEY `idx_141e9a66cae21d54bd05b51a5d007985` (`entryId`,`sortOrder`),
  CONSTRAINT `entries_authors_authorid_foreign` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_authors_entryid_foreign` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uiLabelFormat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{title}',
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8mb4_unicode_ci,
  `titleFormat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowLineBreaksInTitles` tinyint(1) NOT NULL DEFAULT '0',
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text COLLATE utf8mb4_unicode_ci,
  `showStatusField` tinyint(1) DEFAULT '1',
  `showPostDateField` tinyint(1) NOT NULL DEFAULT '1',
  `showExpiryDateField` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_985743a65375cb27ddff6f3cfe982475` (`fieldLayoutId`),
  KEY `idx_605561b95557a53fd76838e983ef9a32` (`dateDeleted`),
  CONSTRAINT `entrytypes_fieldlayoutid_foreign` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,2,'Default','default',NULL,NULL,NULL,'{title}',1,'site',NULL,NULL,0,1,'site',NULL,1,1,1,'2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'8a11481b-da87-47ae-9626-e572ab131c0e');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_4c3a5a2ab6ab50e40349a83c1f9bb92e` (`dateDeleted`),
  KEY `idx_c4cd385b3bcce0ecd65cf8da4d5ea309` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'CraftCms\\Cms\\Asset\\Elements\\Asset','{\"tabs\": [{\"uid\": \"dedfe53e-33df-4be8-9e6b-211ce7708d01\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"515acf27-9308-4456-9be5-67a43aa869d5\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"errors\": [], \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": null, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"instructionsPosition\": \"before\", \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"thumbFieldKey\": null, \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'61901fd3-e169-4772-9241-fe3451ba2020'),(2,'CraftCms\\Cms\\Entry\\Elements\\Entry','{\"tabs\": [{\"uid\": \"a0b44d4e-e743-4d49-8103-d61443d93084\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"2a1db6f4-dbe1-4012-b9cd-3b6848ff686b\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"errors\": [], \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": null, \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"instructionsPosition\": \"before\", \"inputContainerAttributes\": []}, {\"uid\": \"2aa4d56b-b1c6-48a9-b853-643b59caabcb\", \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Heading\", \"errors\": [], \"heading\": \"Hero\", \"dateAdded\": null, \"userCondition\": null, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"391b8f8f-308d-4090-b42d-c700f95e63e5\", \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\", \"label\": \"Headline\", \"width\": 50, \"errors\": [], \"handle\": \"headline\", \"warning\": null, \"fieldUid\": \"a26b11c0-da8e-418d-8a51-fc5d4411134c\", \"required\": false, \"dateAdded\": null, \"oldFieldUid\": null, \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null, \"instructionsPosition\": \"before\"}, {\"tip\": null, \"uid\": \"2b90f4d4-ffff-45d4-b352-8157b56cceb1\", \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\", \"label\": null, \"width\": 50, \"errors\": [], \"handle\": null, \"warning\": null, \"fieldUid\": \"7bfe9119-221f-4a6f-b450-86b1f81fb4cb\", \"required\": false, \"dateAdded\": null, \"oldFieldUid\": null, \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null, \"instructionsPosition\": \"before\"}, {\"tip\": null, \"uid\": \"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\", \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\", \"label\": \"Intro Text\", \"width\": 50, \"errors\": [], \"handle\": \"introText\", \"warning\": null, \"fieldUid\": \"76f4bb16-621b-47e6-a47b-b42a0741bdf4\", \"required\": false, \"dateAdded\": null, \"oldFieldUid\": null, \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null, \"instructionsPosition\": \"before\"}, {\"uid\": \"cc582e20-ba12-4d16-b46c-e1e7e77617f8\", \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Heading\", \"errors\": [], \"heading\": \"Content\", \"dateAdded\": null, \"userCondition\": null, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\", \"type\": \"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\", \"label\": \"Content\", \"width\": 100, \"errors\": [], \"handle\": \"content\", \"warning\": null, \"fieldUid\": \"e7a19cdd-1559-4d99-baf1-63812a369060\", \"required\": false, \"dateAdded\": null, \"oldFieldUid\": null, \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null, \"instructionsPosition\": \"before\"}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"thumbFieldKey\": null, \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'a682e542-8a11-450b-9a5e-f0edddf7bc97');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldreferences`
--

DROP TABLE IF EXISTS `fieldreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldreferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldInstanceUid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_2b58febd8ec5b6f5c8493264ae12699d` (`fieldId`,`fieldInstanceUid`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_9783466b138212930822e02047fed290` (`targetId`),
  KEY `fieldreferences_sourceid_foreign` (`sourceId`),
  KEY `fieldreferences_sourcesiteid_foreign` (`sourceSiteId`),
  CONSTRAINT `fieldreferences_fieldid_foreign` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldreferences_sourceid_foreign` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldreferences_sourcesiteid_foreign` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldreferences`
--

LOCK TABLES `fieldreferences` WRITE;
/*!40000 ALTER TABLE `fieldreferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `fieldreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `translationKeyFormat` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_084f37f4c6a98aa21da6bdcb43269597` (`handle`,`context`),
  KEY `idx_0d9d2cf71233522fca0c46d4bf4460fd` (`context`),
  KEY `idx_212c0dccd0d55604bbb2c7d9d53b35b8` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Plain Text','plainText','global',NULL,0,'site',NULL,'CraftCms\\Cms\\Field\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2026-10-07 08:25:28','2026-10-07 01:26:14',NULL,'a26b11c0-da8e-418d-8a51-fc5d4411134c'),(2,'Asset','asset','global',NULL,0,'none',NULL,'CraftCms\\Cms\\Field\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"branchLimit\":null,\"defaultPlacement\":\"end\",\"defaultUploadLocationSource\":\"volume:086104d4-cbc2-4ac3-aba8-706b10fb7576\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":null,\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\",\"fieldContext\":\"global\",\"forQuery\":false,\"class\":\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\AssetCondition\",\"conditionRules\":{\"operator\":\"and\",\"rules\":[{\"class\":\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\ViewableConditionRule\",\"uid\":\"d4d6f900-3e75-4e07-938c-f3f9d8b831cc\",\"value\":true}]}},\"selectionLabel\":null,\"showSearchInput\":true,\"showSiteMenu\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'7bfe9119-221f-4a6f-b450-86b1f81fb4cb'),(3,'Richtext','richtext','global',NULL,0,'site',NULL,'CraftCms\\Cms\\Field\\Markdown','{\"assetSelectionCondition\":{\"elementType\":\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\",\"fieldContext\":\"global\",\"forQuery\":false,\"class\":\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\AssetCondition\",\"conditionRules\":{\"operator\":\"and\",\"rules\":[{\"class\":\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\ViewableConditionRule\",\"uid\":\"7f92b5a2-3b36-4ae9-84c4-d3bd03109107\",\"value\":true}]}},\"availableVolumes\":\"*\",\"byteLimit\":null,\"charLimit\":null,\"encode\":false,\"flavor\":\"gfm\",\"htmlSanitizer\":null,\"initialRows\":8,\"inlineOnly\":false,\"linkSettingsShowLabelField\":false,\"linkSettingsTypes\":[\"entry\",\"url\"],\"placeholder\":null,\"sanitizeHtml\":true,\"showStats\":false,\"showToolbar\":true,\"showUnpermittedVolumes\":false,\"toolbarButtons\":[\"bold\",\"italic\",\"strikethrough\",\"code\",\"h1\",\"h2\",\"h3\",\"quote\",\"unordered-list\",\"ordered-list\",\"check-list\",\"link\",\"asset\",\"preview\",\"guide\"],\"uploadVolume\":null}','2026-10-07 08:25:28','2026-10-07 01:26:12',NULL,'76f4bb16-621b-47e6-a47b-b42a0741bdf4'),(4,'Richtext Large','richtextLarge','global',NULL,0,'site',NULL,'CraftCms\\Cms\\Field\\Markdown','{\"assetSelectionCondition\":{\"elementType\":\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\",\"fieldContext\":\"global\",\"forQuery\":false,\"class\":\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\AssetCondition\",\"conditionRules\":{\"operator\":\"and\",\"rules\":[{\"class\":\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\ViewableConditionRule\",\"uid\":\"5fbdbea5-371d-4f42-9457-806c302d6a18\",\"value\":true}]}},\"availableVolumes\":\"*\",\"byteLimit\":null,\"charLimit\":null,\"encode\":false,\"flavor\":\"gfm\",\"htmlSanitizer\":null,\"initialRows\":8,\"inlineOnly\":false,\"linkSettingsShowLabelField\":false,\"linkSettingsTypes\":[\"entry\",\"url\"],\"placeholder\":null,\"sanitizeHtml\":true,\"showStats\":false,\"showToolbar\":true,\"showUnpermittedVolumes\":false,\"toolbarButtons\":[\"bold\",\"italic\",\"strikethrough\",\"code\",\"h1\",\"h2\",\"h3\",\"quote\",\"unordered-list\",\"ordered-list\",\"check-list\",\"link\",\"asset\",\"preview\",\"guide\"],\"uploadVolume\":null}','2026-10-07 08:25:28','2026-10-07 01:26:13',NULL,'e7a19cdd-1559-4d99-baf1-63812a369060');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2026-10-07 04:26:01','2026-10-07 04:26:01','4b27d877-0924-47cc-8a6f-b2a591a7f796');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessToken` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_9bb5df4eee90176651c770eb5bb6683c` (`accessToken`),
  UNIQUE KEY `idx_a6c64ee08bea333142fd7b16b3ca2f31` (`name`),
  KEY `gqltokens_schemaid_foreign` (`schemaId`),
  CONSTRAINT `gqltokens_schemaid_foreign` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transformString` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_83ee252382f207a53d12cb0a6d6930b7` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (1,4,'0f7dbd20-f39e-57db-8b25-dcadccdd1733','dashboard.png',NULL,'_30x30_fit_center-center_none',1,0,0,'2026-10-07 11:26:00','2026-10-07 11:26:00','2026-10-07 11:26:00','b230b3f9-ddda-4481-b103-588d985bf0f7'),(2,4,'0f7dbd20-f39e-57db-8b25-dcadccdd1733','dashboard.png',NULL,'_60x60_fit_center-center_none',0,0,0,'2026-10-07 11:26:00','2026-10-07 11:26:00','2026-10-07 11:26:00','10edbd34-84a0-4a1d-9184-e562d6e156d3');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `fill` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameters` json DEFAULT NULL,
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_550315475155ae2ccfaaa6097af2ea13` (`name`),
  KEY `idx_1f063dce8256f4b779b4933f78c1fb06` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configVersion` char(12) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'6.0.0-alpha.19','6.0.0.21','idhuawgwwmxk','2026-10-07 08:17:21','2026-10-07 04:26:01','01a11570-44d3-721d-bbc0-799d1959dbd9');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobprogress`
--

DROP TABLE IF EXISTS `jobprogress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobprogress` (
  `uid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint unsigned NOT NULL DEFAULT '1',
  `progress` tinyint unsigned NOT NULL DEFAULT '0',
  `delay` int unsigned DEFAULT NULL,
  `progressLabel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_ci,
  `dateCompleted` datetime DEFAULT NULL,
  `dateFailed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobprogress`
--

LOCK TABLES `jobprogress` WRITE;
/*!40000 ALTER TABLE `jobprogress` DISABLE KEYS */;
INSERT INTO `jobprogress` VALUES ('0ef66d92-cc53-4fe7-83c3-d8d997637818','t9n:[\"Pruning extra revisions\"]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),('0f699e1b-77b0-41ea-bd45-5df00bddd44b','t9n:[\"Generating image transform for {file}\",{\"file\":\"dashboard.png\"}]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 04:26:00','2026-10-07 04:26:00'),('1176d7a2-e613-4fa9-9da1-4580a57ecc9e','t9n:[\"Propagating {type}\",{\"type\":\"assets\"}]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 08:25:28','2026-10-07 08:25:28'),('252ffa2b-719b-4475-92b7-53fd3ec23ab2','t9n:[\"Pruning extra revisions\"]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 01:27:50','2026-10-07 01:27:50'),('4a8f6491-895d-445b-bf73-2876f8675ffb','t9n:[\"Pruning extra revisions\"]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),('6745f25a-d92f-4da5-9bbf-9cc24d52df35','t9n:[\"Pruning extra revisions\"]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 08:25:28','2026-10-07 08:25:28'),('87e3cadb-3bdc-4854-bfdf-dc091d6078f9','t9n:[\"Pruning extra revisions\"]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),('8910d26d-388e-4475-b4fb-8e05b5066523','t9n:[\"Pruning extra revisions\"]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49'),('8a271727-2af3-4cf7-91b8-a64686ead2a7','t9n:[\"Generating image transform for {file}\",{\"file\":\"dashboard.png\"}]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 04:26:00','2026-10-07 04:26:00'),('c89149c3-7664-4428-b02b-e342f8eb4f7f','t9n:[\"Propagating {type}\",{\"type\":\"assets\"}]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 08:25:28','2026-10-07 08:25:28'),('caa00d9a-1d4b-4337-ac87-fb1ca480b9f8','t9n:[\"Pruning extra revisions\"]',1,0,NULL,NULL,NULL,NULL,NULL,'2026-10-07 01:27:49','2026-10-07 01:27:49');
/*!40000 ALTER TABLE `jobprogress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'default','{\"uuid\":\"c89149c3-7664-4428-b02b-e342f8eb4f7f\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PropagateElements\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PropagateElements\",\"command\":\"O:43:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PropagateElements\\\":5:{s:6:\\\"siteId\\\";a:1:{i:0;i:2;}s:14:\\\"\\u0000*\\u0000elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\\\";s:11:\\\"\\u0000*\\u0000criteria\\\";a:1:{s:6:\\\"siteId\\\";i:1;}s:9:\\\"isNewSite\\\";b:1;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361528,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"CraftCms\\\\Cms\\\\Edition\":\"E:25:\\\"CraftCms\\\\Cms\\\\Edition:Solo\\\";\",\"craft.isInstalled\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361528,1791361528),(2,'default','{\"uuid\":\"1176d7a2-e613-4fa9-9da1-4580a57ecc9e\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PropagateElements\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PropagateElements\",\"command\":\"O:43:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PropagateElements\\\":5:{s:6:\\\"siteId\\\";a:1:{i:0;i:3;}s:14:\\\"\\u0000*\\u0000elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\\\";s:11:\\\"\\u0000*\\u0000criteria\\\";a:1:{s:6:\\\"siteId\\\";i:1;}s:9:\\\"isNewSite\\\";b:1;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361528,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"CraftCms\\\\Cms\\\\Edition\":\"E:25:\\\"CraftCms\\\\Cms\\\\Edition:Solo\\\";\",\"craft.isInstalled\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361528,1791361528),(3,'default','{\"uuid\":\"6745f25a-d92f-4da5-9bbf-9cc24d52df35\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"command\":\"O:40:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\\\":5:{s:11:\\\"elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Entry\\\\Elements\\\\Entry\\\";s:11:\\\"canonicalId\\\";i:2;s:6:\\\"siteId\\\";i:1;s:12:\\\"maxRevisions\\\";N;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361528,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"CraftCms\\\\Cms\\\\Edition\":\"E:25:\\\"CraftCms\\\\Cms\\\\Edition:Solo\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.supportsMb4\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361528,1791361528),(4,'default','{\"uuid\":\"87e3cadb-3bdc-4854-bfdf-dc091d6078f9\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"command\":\"O:40:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\\\":5:{s:11:\\\"elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Entry\\\\Elements\\\\Entry\\\";s:11:\\\"canonicalId\\\";i:2;s:6:\\\"siteId\\\";i:1;s:12:\\\"maxRevisions\\\";N;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361669,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"craft.supportsMb4\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361669,1791361669),(5,'default','{\"uuid\":\"4a8f6491-895d-445b-bf73-2876f8675ffb\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"command\":\"O:40:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\\\":5:{s:11:\\\"elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Entry\\\\Elements\\\\Entry\\\";s:11:\\\"canonicalId\\\";i:2;s:6:\\\"siteId\\\";i:2;s:12:\\\"maxRevisions\\\";N;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361669,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"craft.supportsMb4\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361669,1791361669),(6,'default','{\"uuid\":\"caa00d9a-1d4b-4337-ac87-fb1ca480b9f8\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"command\":\"O:40:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\\\":5:{s:11:\\\"elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Entry\\\\Elements\\\\Entry\\\";s:11:\\\"canonicalId\\\";i:2;s:6:\\\"siteId\\\";i:3;s:12:\\\"maxRevisions\\\";N;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361669,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"craft.supportsMb4\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361669,1791361669),(7,'default','{\"uuid\":\"0ef66d92-cc53-4fe7-83c3-d8d997637818\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"command\":\"O:40:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\\\":5:{s:11:\\\"elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Entry\\\\Elements\\\\Entry\\\";s:11:\\\"canonicalId\\\";i:8;s:6:\\\"siteId\\\";i:1;s:12:\\\"maxRevisions\\\";N;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361669,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"craft.supportsMb4\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361669,1791361669),(8,'default','{\"uuid\":\"8910d26d-388e-4475-b4fb-8e05b5066523\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"command\":\"O:40:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\\\":5:{s:11:\\\"elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Entry\\\\Elements\\\\Entry\\\";s:11:\\\"canonicalId\\\";i:8;s:6:\\\"siteId\\\";i:2;s:12:\\\"maxRevisions\\\";N;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361669,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"craft.supportsMb4\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361669,1791361669),(9,'default','{\"uuid\":\"252ffa2b-719b-4475-92b7-53fd3ec23ab2\",\"displayName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\",\"command\":\"O:40:\\\"CraftCms\\\\Cms\\\\Element\\\\Jobs\\\\PruneRevisions\\\":5:{s:11:\\\"elementType\\\";s:33:\\\"CraftCms\\\\Cms\\\\Entry\\\\Elements\\\\Entry\\\";s:11:\\\"canonicalId\\\";i:8;s:6:\\\"siteId\\\";i:3;s:12:\\\"maxRevisions\\\";N;s:5:\\\"queue\\\";s:7:\\\"default\\\";}\",\"batchId\":null},\"createdAt\":1791361670,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"craft.supportsMb4\":\"b:1;\"}},\"delay\":null}',0,NULL,1791361670,1791361670),(10,'default','{\"uuid\":\"0f699e1b-77b0-41ea-bd45-5df00bddd44b\",\"displayName\":\"CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform\",\"command\":\"O:46:\\\"CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform\\\":4:{s:11:\\\"transformId\\\";i:1;s:14:\\\"\\u0000*\\u0000description\\\";s:70:\\\"t9n:[\\\"Generating image transform for {file}\\\",{\\\"file\\\":\\\"dashboard.png\\\"}]\\\";s:5:\\\"queue\\\";s:7:\\\"default\\\";s:15:\\\"uniqueLockOwner\\\";s:16:\\\"nTgbMk2n9TMTA7A2\\\";}\",\"batchId\":null},\"createdAt\":1791372360,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"laravel_unique_job_cache_store\":\"s:4:\\\"file\\\";\",\"laravel_unique_job_key\":\"s:67:\\\"laravel_unique_job:CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform:1\\\";\",\"laravel_unique_job_lock_owner\":\"s:16:\\\"nTgbMk2n9TMTA7A2\\\";\"}},\"delay\":null}',0,NULL,1791372360,1791372360),(11,'default','{\"uuid\":\"8a271727-2af3-4cf7-91b8-a64686ead2a7\",\"displayName\":\"CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"countCrashesAsExceptions\":false,\"backoff\":null,\"timeout\":300,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform\",\"command\":\"O:46:\\\"CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform\\\":4:{s:11:\\\"transformId\\\";i:2;s:14:\\\"\\u0000*\\u0000description\\\";s:70:\\\"t9n:[\\\"Generating image transform for {file}\\\",{\\\"file\\\":\\\"dashboard.png\\\"}]\\\";s:5:\\\"queue\\\";s:7:\\\"default\\\";s:15:\\\"uniqueLockOwner\\\";s:16:\\\"9XmxmXgg3j7t6xHJ\\\";}\",\"batchId\":null},\"createdAt\":1791372360,\"illuminate:log:context\":{\"data\":[],\"hidden\":{\"CraftCms\\\\Cms\\\\Edition\":\"E:24:\\\"CraftCms\\\\Cms\\\\Edition:Pro\\\";\",\"CraftCms\\\\Cms\\\\View\\\\TemplateMode\":\"E:33:\\\"CraftCms\\\\Cms\\\\View\\\\TemplateMode:Cp\\\";\",\"craft.isInstalled\":\"b:1;\",\"craft.info\":\"O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"CraftCms\\\\Cms\\\\Shared\\\\Models\\\\Info\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}\",\"laravel_unique_job_cache_store\":\"s:4:\\\"file\\\";\",\"laravel_unique_job_key\":\"s:67:\\\"laravel_unique_job:CraftCms\\\\Cms\\\\Image\\\\Jobs\\\\GenerateImageTransform:2\\\";\",\"laravel_unique_job_lock_owner\":\"s:16:\\\"9XmxmXgg3j7t6xHJ\\\";\"}},\"delay\":null}',0,NULL,1791372360,1791372360);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `track` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,NULL,'0001_01_01_000001_create_cache_table',1),(2,NULL,'0001_01_01_000002_create_jobs_table',1),(3,'craft','Install',1),(4,'craft','0000_00_00_000001_add_remember_token_to_users',1),(5,'craft','0000_00_00_000002_migrate_widget_types',1),(6,'craft','0000_00_00_000003_remove_craftidtokens_table',1),(7,'craft','0000_00_00_000004_migrate_field_types',1),(8,'craft','0000_00_00_000005_rename_tokens_to_routetokens',1),(9,'craft','0000_00_00_000006_create_password_reset_tokens_table',1),(10,'craft','0000_00_00_000007_migrate_to_laravel_queue',1),(11,'craft','0000_00_00_000008_remove_field_version',1),(12,'craft','0000_00_00_000009_remove_maintenance_from_info',1),(13,'craft','0000_00_00_000010_migrate_entry_types',1),(14,'craft','2026_01_20_120907_line_breaks_in_titles',1),(15,'craft','2026_04_01_155236_min_authors_setting',1),(16,'craft','2026_06_01_000000_create_fieldreferences_table',1),(17,'craft','2026_06_02_230524_link_references',1),(18,'craft','2026_06_10_112441_drop_assets_alt_column',1),(19,'craft','2026_07_15_000000_encrypt_recovery_codes',1),(20,'craft','2026_08_12_143000_drop_elementactivity_draftid_fk',1),(21,'craft','2026_08_14_000000_asset_transformers',1),(22,'craft','2026_08_17_000000_replace_asset_index_flags_with_status',1),(23,'craft','2026_08_18_165555_add_date_columns_to_jobprogress',1),(24,'craft','2026_08_25_000000_create_activityevents_table',1),(25,'craft','2026_08_31_181802_remove_system.live',1),(26,'craft','2026_09_01_000000_remove_craft_filesystems',1),(27,'craft','2026_09_01_160000_replace_announcements_with_notifications',1),(28,'craft','2026_09_08_101230_create_upload_sessions_table',1),(29,'craft','2026_09_10_231959_drop_redundant_field_settings',1),(30,'craft','2026_09_11_000000_add_selection_conditions_to_link_and_markdown_fields',1),(31,'craft','2026_09_13_000000_create_workflow_tables',1),(32,'craft','2026_09_18_120000_add_entry_type_show_post_and_expiry_date_fields',1),(33,'craft','2026_09_27_000000_migrate_field_layout_element_types',1),(34,'craft','2026_09_27_065350_migrate_stored_condition_types',1),(35,'craft','2026_09_30_000000_add_colors_to_assets',1),(36,'craft','2026_09_30_000001_add_section_site_routes',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schemaVersion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_78ee05ab9d13d9c48df0bc95f69adca3` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('assetTransformers.0f7dbd20-f39e-57db-8b25-dcadccdd1733.driver','\"craft\"'),('assetTransformers.0f7dbd20-f39e-57db-8b25-dcadccdd1733.handle','\"craft\"'),('assetTransformers.0f7dbd20-f39e-57db-8b25-dcadccdd1733.name','\"Craft\"'),('assetTransformers.0f7dbd20-f39e-57db-8b25-dcadccdd1733.settings.disk','null'),('assetTransformers.0f7dbd20-f39e-57db-8b25-dcadccdd1733.settings.generateTransformsBeforePageLoad','false'),('assetTransformers.0f7dbd20-f39e-57db-8b25-dcadccdd1733.settings.hasUrls','false'),('assetTransformers.0f7dbd20-f39e-57db-8b25-dcadccdd1733.settings.subpath','null'),('dateModified','1791372361'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.allowLineBreaksInTitles','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.color','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.description','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.cardThumbAlignment','\"end\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.autocapitalize','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.autocomplete','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.autocorrect','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.class','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.dateAdded','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.disabled','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.id','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.inputType','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.instructions','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.instructionsPosition','\"before\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.label','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.max','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.min','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.name','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.orientation','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.placeholder','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.readonly','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.required','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.size','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.step','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.tip','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.title','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Entries\\\\EntryTitleField\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.uid','\"2a1db6f4-dbe1-4012-b9cd-3b6848ff686b\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.warning','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.0.width','100'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.1.dateAdded','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.1.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.1.heading','\"Hero\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.1.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Heading\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.1.uid','\"2aa4d56b-b1c6-48a9-b853-643b59caabcb\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.1.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.dateAdded','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.editCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.elementEditCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.fieldUid','\"a26b11c0-da8e-418d-8a51-fc5d4411134c\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.handle','\"headline\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.instructions','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.instructionsPosition','\"before\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.label','\"Headline\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.oldFieldUid','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.required','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.tip','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.uid','\"391b8f8f-308d-4090-b42d-c700f95e63e5\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.warning','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.2.width','50'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.dateAdded','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.editCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.elementEditCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.fieldUid','\"7bfe9119-221f-4a6f-b450-86b1f81fb4cb\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.handle','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.instructions','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.instructionsPosition','\"before\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.label','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.oldFieldUid','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.required','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.tip','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.uid','\"2b90f4d4-ffff-45d4-b352-8157b56cceb1\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.warning','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.3.width','50'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.dateAdded','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.editCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.elementEditCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.fieldUid','\"76f4bb16-621b-47e6-a47b-b42a0741bdf4\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.handle','\"introText\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.instructions','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.instructionsPosition','\"before\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.label','\"Intro Text\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.oldFieldUid','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.required','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.tip','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.uid','\"0f2ccff6-e12e-4bf5-b550-f79c3698e43f\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.warning','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.4.width','50'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.5.dateAdded','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.5.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.5.heading','\"Content\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.5.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Heading\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.5.uid','\"cc582e20-ba12-4d16-b46c-e1e7e77617f8\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.5.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.dateAdded','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.editCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.elementCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.elementEditCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.fieldUid','\"e7a19cdd-1559-4d99-baf1-63812a369060\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.handle','\"content\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.instructions','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.instructionsPosition','\"before\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.label','\"Content\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.oldFieldUid','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.required','false'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.tip','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\CustomField\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.uid','\"4d5f9302-a0dc-48ab-b58d-e36ffd1c82df\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.warning','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.elements.6.width','100'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.name','\"Content\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.uid','\"a0b44d4e-e743-4d49-8103-d61443d93084\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.tabs.0.userCondition','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.fieldLayouts.a682e542-8a11-450b-9a5e-f0edddf7bc97.thumbFieldKey','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.handle','\"default\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.hasTitleField','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.icon','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.name','\"Default\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.showExpiryDateField','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.showPostDateField','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.showSlugField','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.showStatusField','true'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.slugTranslationKeyFormat','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.slugTranslationMethod','\"site\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.titleFormat','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.titleTranslationKeyFormat','null'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.titleTranslationMethod','\"site\"'),('entryTypes.8a11481b-da87-47ae-9626-e572ab131c0e.uiLabelFormat','\"{title}\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.handle','\"richtext\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.instructions','null'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.name','\"Richtext\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.searchable','false'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.0.0','\"elementType\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.0.1','\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.1.1','\"global\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.2.0','\"forQuery\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.2.1','false'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.3.0','\"class\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.3.1','\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\AssetCondition\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.0','\"conditionRules\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.0.0','\"operator\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.0.1','\"and\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.0','\"rules\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.0.0','\"class\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.0.1','\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\ViewableConditionRule\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.1.0','\"uid\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.1.1','\"7f92b5a2-3b36-4ae9-84c4-d3bd03109107\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.2.0','\"value\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.2.1','true'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.availableVolumes','\"*\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.byteLimit','null'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.charLimit','null'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.encode','false'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.flavor','\"gfm\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.htmlSanitizer','null'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.initialRows','8'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.inlineOnly','false'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.linkSettingsShowLabelField','false'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.linkSettingsTypes.0','\"entry\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.linkSettingsTypes.1','\"url\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.placeholder','null'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.sanitizeHtml','true'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.showStats','false'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.showToolbar','true'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.showUnpermittedVolumes','false'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.0','\"bold\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.1','\"italic\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.10','\"check-list\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.11','\"link\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.12','\"asset\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.13','\"preview\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.14','\"guide\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.2','\"strikethrough\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.3','\"code\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.4','\"h1\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.5','\"h2\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.6','\"h3\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.7','\"quote\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.8','\"unordered-list\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.toolbarButtons.9','\"ordered-list\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.settings.uploadVolume','null'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.translationKeyFormat','null'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.translationMethod','\"site\"'),('fields.76f4bb16-621b-47e6-a47b-b42a0741bdf4.type','\"CraftCms\\\\Cms\\\\Field\\\\Markdown\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.handle','\"asset\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.instructions','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.name','\"Asset\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.searchable','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.allowSelfRelations','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.allowSubfolders','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.allowUploads','true'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.branchLimit','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.defaultPlacement','\"end\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.defaultUploadLocationSource','\"volume:086104d4-cbc2-4ac3-aba8-706b10fb7576\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.defaultUploadLocationSubpath','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.maintainHierarchy','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.maxRelations','1'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.minRelations','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.previewMode','\"full\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.restrictedDefaultUploadSubpath','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.restrictedLocationSource','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.restrictedLocationSubpath','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.restrictLocation','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.0.1','\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.2.0','\"forQuery\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.2.1','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.3.0','\"class\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.3.1','\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\AssetCondition\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.0','\"conditionRules\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.0.0','\"operator\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.0.1','\"and\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.1.0','\"rules\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.0.0','\"class\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.0.1','\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\ViewableConditionRule\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.1.0','\"uid\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.1.1','\"d4d6f900-3e75-4e07-938c-f3f9d8b831cc\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.2.0','\"value\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.2.1','true'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.selectionLabel','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.showSearchInput','true'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.showSiteMenu','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.showUnpermittedVolumes','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.sources','\"*\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.targetSiteId','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.validateRelatedElements','false'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.settings.viewMode','\"list\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.translationKeyFormat','null'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.translationMethod','\"none\"'),('fields.7bfe9119-221f-4a6f-b450-86b1f81fb4cb.type','\"CraftCms\\\\Cms\\\\Field\\\\Assets\"'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.handle','\"plainText\"'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.instructions','null'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.name','\"Plain Text\"'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.searchable','false'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.settings.byteLimit','null'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.settings.charLimit','null'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.settings.code','false'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.settings.initialRows','4'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.settings.multiline','false'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.settings.placeholder','null'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.settings.uiMode','\"normal\"'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.translationKeyFormat','null'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.translationMethod','\"site\"'),('fields.a26b11c0-da8e-418d-8a51-fc5d4411134c.type','\"CraftCms\\\\Cms\\\\Field\\\\PlainText\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.handle','\"richtextLarge\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.instructions','null'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.name','\"Richtext Large\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.searchable','false'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.0.0','\"elementType\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.0.1','\"CraftCms\\\\Cms\\\\Asset\\\\Elements\\\\Asset\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.1.1','\"global\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.2.0','\"forQuery\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.2.1','false'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.3.0','\"class\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.3.1','\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\AssetCondition\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.0','\"conditionRules\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.0.0','\"operator\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.0.1','\"and\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.0','\"rules\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.0.0','\"class\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.0.1','\"CraftCms\\\\Cms\\\\Asset\\\\Conditions\\\\ViewableConditionRule\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.1.0','\"uid\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.1.1','\"5fbdbea5-371d-4f42-9457-806c302d6a18\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.2.0','\"value\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.assetSelectionCondition.__assoc__.4.1.__assoc__.1.1.0.__assoc__.2.1','true'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.availableVolumes','\"*\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.byteLimit','null'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.charLimit','null'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.encode','false'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.flavor','\"gfm\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.htmlSanitizer','null'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.initialRows','8'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.inlineOnly','false'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.linkSettingsShowLabelField','false'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.linkSettingsTypes.0','\"entry\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.linkSettingsTypes.1','\"url\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.placeholder','null'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.sanitizeHtml','true'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.showStats','false'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.showToolbar','true'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.showUnpermittedVolumes','false'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.0','\"bold\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.1','\"italic\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.10','\"check-list\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.11','\"link\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.12','\"asset\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.13','\"preview\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.14','\"guide\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.2','\"strikethrough\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.3','\"code\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.4','\"h1\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.5','\"h2\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.6','\"h3\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.7','\"quote\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.8','\"unordered-list\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.toolbarButtons.9','\"ordered-list\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.settings.uploadVolume','null'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.translationKeyFormat','null'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.translationMethod','\"site\"'),('fields.e7a19cdd-1559-4d99-baf1-63812a369060.type','\"CraftCms\\\\Cms\\\\Field\\\\Markdown\"'),('graphql.publicToken.enabled','false'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.4b27d877-0924-47cc-8a6f-b2a591a7f796.isPublic','true'),('graphql.schemas.4b27d877-0924-47cc-8a6f-b2a591a7f796.name','\"Public Schema\"'),('meta.__names__.086104d4-cbc2-4ac3-aba8-706b10fb7576','\"Images\"'),('meta.__names__.0f7dbd20-f39e-57db-8b25-dcadccdd1733','\"Craft\"'),('meta.__names__.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a','\"Pages\"'),('meta.__names__.4b27d877-0924-47cc-8a6f-b2a591a7f796','\"Public Schema\"'),('meta.__names__.68bcc1ae-e3c4-486f-8d76-e6db3fe1a93f','\"Knecht Works\"'),('meta.__names__.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d','\"EN\"'),('meta.__names__.76f4bb16-621b-47e6-a47b-b42a0741bdf4','\"Richtext\"'),('meta.__names__.7bfe9119-221f-4a6f-b450-86b1f81fb4cb','\"Asset\"'),('meta.__names__.8a11481b-da87-47ae-9626-e572ab131c0e','\"Default\"'),('meta.__names__.a26b11c0-da8e-418d-8a51-fc5d4411134c','\"Plain Text\"'),('meta.__names__.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be','\"Home\"'),('meta.__names__.dee56a08-c55c-4108-a4af-fea2b06d9dd0','\"DE\"'),('meta.__names__.e2b05374-8ac3-4487-a137-e43cc30ddd9a','\"GB\"'),('meta.__names__.e7a19cdd-1559-4d99-baf1-63812a369060','\"Richtext Large\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.defaultPlacement','\"end\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.enableVersioning','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.entryTypes.0.uid','\"8a11481b-da87-47ae-9626-e572ab131c0e\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.handle','\"pages\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.maxAuthors','1'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.minAuthors','1'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.name','\"Pages\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.previewTargets.0.label','\"Primary entry page\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.previewTargets.0.refresh','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.previewTargets.0.urlFormat','\"{url}\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.propagationMethod','\"all\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.enabledByDefault','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.hasUrls','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.route','null'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.template','\"_entry.twig\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.uriFormat','\"{slug}\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.enabledByDefault','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.hasUrls','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.route','null'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.template','\"_entry.twig\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.uriFormat','\"{slug}\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.enabledByDefault','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.hasUrls','true'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.route','null'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.template','\"_entry.twig\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.uriFormat','\"{slug}\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.type','\"channel\"'),('sections.1a1f4c85-de86-4c34-9fb1-f6c0bba5304a.workflow','null'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.defaultPlacement','\"end\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.enableVersioning','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.entryTypes.0.uid','\"8a11481b-da87-47ae-9626-e572ab131c0e\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.handle','\"home\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.maxAuthors','1'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.minAuthors','1'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.name','\"Home\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.previewTargets.0.label','\"Primary entry page\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.previewTargets.0.refresh','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.previewTargets.0.urlFormat','\"{url}\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.propagationMethod','\"all\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.enabledByDefault','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.hasUrls','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.route','null'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.template','\"_entry.twig\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.uriFormat','\"__home__\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.enabledByDefault','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.hasUrls','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.route','null'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.template','\"_entry.twig\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.dee56a08-c55c-4108-a4af-fea2b06d9dd0.uriFormat','\"__home__\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.enabledByDefault','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.hasUrls','true'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.route','null'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.template','\"_entry.twig\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.siteSettings.e2b05374-8ac3-4487-a137-e43cc30ddd9a.uriFormat','\"__home__\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.type','\"single\"'),('sections.b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be.workflow','null'),('siteGroups.68bcc1ae-e3c4-486f-8d76-e6db3fe1a93f.name','\"Knecht Works\"'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.enabled','true'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.handle','\"en\"'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.hasUrls','true'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.language','\"en\"'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.name','\"EN\"'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.primary','true'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.siteGroup','\"68bcc1ae-e3c4-486f-8d76-e6db3fe1a93f\"'),('sites.7480c632-a5a8-4f7c-9f8e-fc97c2b1365d.sortOrder','1'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.baseUrl','\"$PRIMARY_SITE_URL_DE\"'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.enabled','\"1\"'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.handle','\"de\"'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.hasUrls','true'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.language','\"de\"'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.name','\"DE\"'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.primary','false'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.siteGroup','\"68bcc1ae-e3c4-486f-8d76-e6db3fe1a93f\"'),('sites.dee56a08-c55c-4108-a4af-fea2b06d9dd0.sortOrder','2'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.baseUrl','\"$PRIMARY_SITE_URL/gb\"'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.enabled','\"1\"'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.handle','\"gb\"'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.hasUrls','true'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.language','\"en-GB\"'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.name','\"GB\"'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.primary','false'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.siteGroup','\"68bcc1ae-e3c4-486f-8d76-e6db3fe1a93f\"'),('sites.e2b05374-8ac3-4487-a137-e43cc30ddd9a.sortOrder','3'),('system.edition','\"pro\"'),('system.name','\"Knecht Works\"'),('system.schemaVersion','\"6.0.0.21\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.altTranslationKeyFormat','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.altTranslationMethod','\"none\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.assetTransformer','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.cardThumbAlignment','\"end\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elementCondition','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.autocapitalize','true'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.autocomplete','false'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.autocorrect','true'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.class','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.dateAdded','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.disabled','false'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.elementCondition','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.id','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.inputType','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.instructions','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.instructionsPosition','\"before\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.label','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.max','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.min','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.name','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.orientation','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.placeholder','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.readonly','false'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.requirable','false'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.size','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.step','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.tip','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.title','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.type','\"CraftCms\\\\Cms\\\\FieldLayout\\\\LayoutElements\\\\Assets\\\\AssetTitleField\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.uid','\"515acf27-9308-4456-9be5-67a43aa869d5\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.userCondition','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.warning','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.elements.0.width','100'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.name','\"Content\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.uid','\"dedfe53e-33df-4be8-9e6b-211ce7708d01\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.tabs.0.userCondition','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fieldLayouts.61901fd3-e169-4772-9241-fe3451ba2020.thumbFieldKey','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.fs','\"assets\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.handle','\"images\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.hasUrls','true'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.name','\"Images\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.sortOrder','1'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.subpath','\"images\"'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.titleTranslationKeyFormat','null'),('volumes.086104d4-cbc2-4ac3-aba8-706b10fb7576.titleTranslationMethod','\"site\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text COLLATE utf8mb4_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_23b1058764def44643002d4302b46547` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ff7f58fc16375a24057794749260d125` (`sourceId`),
  KEY `idx_1733b941ec09016aa463ad906e61e0fe` (`targetId`),
  KEY `idx_7a620760859e8890faed8620bfc949d8` (`sourceSiteId`),
  CONSTRAINT `relations_fieldid_foreign` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceid_foreign` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourcesiteid_foreign` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (1,2,2,1,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','3fc1f85b-b063-4f30-bbf0-6de9b7b9df86'),(2,2,2,2,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','3ab7edda-5392-4d13-a5c6-f5e51f1442d8'),(3,2,2,3,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','13bc196d-25f0-4bc1-93d9-e3c1f285e9d4'),(4,2,5,1,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','85e42c1f-d6cb-4e87-b484-1e10a91c83d5'),(5,2,5,2,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','7fd14f49-e741-4955-ac21-9621d3d8f281'),(6,2,5,3,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','bcfc0a25-c2b2-4745-9610-0fe2d8e6105f'),(7,2,6,2,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','f3bdb34c-1e71-416d-8e1b-0178f7e55fe0'),(8,2,6,1,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','cdedf4dd-564a-44a9-aef4-1ef5e66fb4e3'),(9,2,6,3,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','33fa318b-778d-4513-8fff-657e82e4ef38'),(10,2,7,3,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','94713089-6756-4034-a13b-46de03ed79ff'),(11,2,7,1,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','fece37a9-6f28-428c-82ba-caed1aa3f4c9'),(12,2,7,2,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','d53a6d67-cf1f-4900-91c1-6a6dbdab3c6d'),(13,2,8,1,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','c4d13bc3-07dc-4d19-9f35-b3d403fb2c7d'),(14,2,8,2,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','1adcbd4c-20af-4ff1-95f3-e731265da8e7'),(15,2,8,3,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','f93454a7-07ed-4152-968d-daac62b77211'),(16,2,9,1,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','86af841f-8f17-4f9b-a910-e2b49a8875a7'),(17,2,9,2,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','e7e060ad-ed3a-4c21-b8d0-e97b61df13fb'),(18,2,9,3,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','ee65e619-9437-428c-be1b-7080db0141b1'),(19,2,10,2,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','5cc49aa4-8451-4519-a54d-f187fd4fe00a'),(20,2,10,1,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','54e311be-9b1f-4ddc-b17d-ab2c03688ad0'),(21,2,10,3,4,1,'2026-10-07 01:27:49','2026-10-07 01:27:49','a7a46f0e-de44-4ed4-b402-b6c229d7b8a8'),(22,2,11,3,4,1,'2026-10-07 01:27:50','2026-10-07 01:27:50','4ac15857-e172-4fd4-b858-3756cc9616ff'),(23,2,11,1,4,1,'2026-10-07 01:27:50','2026-10-07 01:27:50','2caa6d11-33b3-497d-b76e-379704d28078'),(24,2,11,2,4,1,'2026-10-07 01:27:50','2026-10-07 01:27:50','fcb86796-57dd-47ef-848e-5d928049691e');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_5b6d22d976b14832f0c2b8f901de30b2` (`canonicalId`,`num`),
  KEY `revisions_creatorid_foreign` (`creatorId`),
  CONSTRAINT `revisions_canonicalid_foreign` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `revisions_creatorid_foreign` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,NULL,1,NULL),(2,2,NULL,2,NULL),(3,2,NULL,3,NULL),(4,2,NULL,4,NULL),(5,8,NULL,1,NULL),(6,8,NULL,2,NULL),(7,8,NULL,3,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routetokens`
--

DROP TABLE IF EXISTS `routetokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routetokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` text COLLATE utf8mb4_unicode_ci,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_b820688ad2095d72fc753068f8d18a3b` (`token`),
  KEY `idx_22826aac44efee182adf2c0b9fbadc7f` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routetokens`
--

LOCK TABLES `routetokens` WRITE;
/*!40000 ALTER TABLE `routetokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `routetokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_fulltext` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' hallo knecht works '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' home '),(2,'slug',0,2,' home '),(2,'slug',0,3,' home '),(2,'title',0,1,' home '),(2,'title',0,2,' home '),(2,'title',0,3,' home '),(4,'alt',0,1,''),(4,'alt',0,2,''),(4,'alt',0,3,''),(4,'extension',0,1,' png '),(4,'extension',0,2,' png '),(4,'extension',0,3,' png '),(4,'filename',0,1,' dashboard png '),(4,'filename',0,2,' dashboard png '),(4,'filename',0,3,' dashboard png '),(4,'kind',0,1,' image '),(4,'kind',0,2,' image '),(4,'kind',0,3,' image '),(4,'slug',0,1,''),(4,'slug',0,2,''),(4,'slug',0,3,''),(4,'title',0,1,' dashboard '),(4,'title',0,2,' dashboard '),(4,'title',0,3,' dashboard '),(8,'slug',0,1,' news '),(8,'slug',0,2,' news '),(8,'slug',0,3,' news '),(8,'title',0,1,' news '),(8,'title',0,2,' news '),(8,'title',0,3,' news ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_858327617a16be4eec21f1312f1d65a7` (`elementId`,`siteId`,`reserved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_85eb88e29873872c66c4c9ebc21926d4` (`jobId`,`fieldHandle`),
  CONSTRAINT `searchindexqueue_fields_jobid_foreign` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `workflowId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `minAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_f7baedff072057edb00ad289b8bf1260` (`handle`),
  KEY `idx_22cbcf9ffceee583bc472856bb09605d` (`name`),
  KEY `idx_e3eaa826963fe95dd352e46accef336a` (`structureId`),
  KEY `idx_8161bb36b09df49cf138b24834ab6b05` (`dateDeleted`),
  KEY `sections_workflowid_foreign` (`workflowId`),
  CONSTRAINT `sections_structureid_foreign` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sections_workflowid_foreign` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,NULL,'Home','home','single',1,1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": true, \"urlFormat\": \"{url}\"}]','2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'b2dc6ff6-cb1f-4eec-8be3-e974fb8b99be'),(2,NULL,NULL,'Pages','pages','channel',1,1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": true, \"urlFormat\": \"{url}\"}]','2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'1a1f4c85-de86-4c34-9fb1-f6c0bba5304a');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `sections_entrytypes_typeid_foreign` (`typeId`),
  CONSTRAINT `sections_entrytypes_sectionid_foreign` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_entrytypes_typeid_foreign` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1,NULL,NULL,NULL),(2,1,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8mb4_unicode_ci,
  `template` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_64612a93b87e50aca0330ca1e7e13d5f` (`sectionId`,`siteId`),
  KEY `idx_d8151d5ab9705f1d1df9eda5e7c2c1e9` (`siteId`),
  CONSTRAINT `sections_sites_sectionid_foreign` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteid_foreign` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','_entry.twig',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','01a11577-b400-7057-8a81-bbcb6f3b3e53'),(2,1,2,1,'__home__','_entry.twig',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','01a11577-b400-7057-8a81-bbcb6fdb1d43'),(3,1,3,1,'__home__','_entry.twig',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','01a11577-b401-736c-a4ec-c60187e6e7cd'),(4,2,1,1,'{slug}','_entry.twig',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','01a11577-b469-7345-900b-59157b7a38f2'),(5,2,2,1,'{slug}','_entry.twig',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','01a11577-b469-7345-900b-59157bce89ce'),(6,2,3,1,'{slug}','_entry.twig',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28','01a11577-b46a-711c-9ba3-07c572ed00f9');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_0bafab498d9bf985e9c952aca3166c4c` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_196aa438f09e4e4d673b06b36d78c520` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Knecht Works','2026-10-07 08:17:21','2026-10-07 08:25:28',NULL,'68bcc1ae-e3c4-486f-8d76-e6db3fe1a93f');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'true',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_b87e68f8efa30509274dc6202d40197a` (`dateDeleted`),
  KEY `idx_7da2c7cab73a4f0d046cbabb9c181288` (`handle`),
  KEY `idx_f1eebb0fcb2a9c7bb6d536bc6c518fde` (`sortOrder`),
  KEY `sites_groupid_foreign` (`groupId`),
  CONSTRAINT `sites_groupid_foreign` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','EN','en','en',1,'$PRIMARY_SITE_URL',1,'2026-10-07 08:17:21','2026-10-07 08:25:28',NULL,'7480c632-a5a8-4f7c-9f8e-fc97c2b1365d'),(2,1,0,'1','DE','de','de',1,'$PRIMARY_SITE_URL_DE',2,'2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'dee56a08-c55c-4108-a4af-fea2b06d9dd0'),(3,1,0,'1','GB','gb','en-GB',1,'$PRIMARY_SITE_URL/gb',3,'2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'e2b05374-8ac3-4487-a137-e43cc30ddd9a');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identityId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `sso_identities_userid_foreign` (`userId`),
  CONSTRAINT `sso_identities_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int NOT NULL,
  `rgt` int NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_68689694da2151268e9b21ba68ff0a4e` (`structureId`,`elementId`),
  KEY `idx_7fb96b8d088a5135da38b5e39ff1d86d` (`root`),
  KEY `idx_ce5bd5f1f5ae9e8604b7cb0fe4148044` (`lft`),
  KEY `idx_0f856ca9000489f3d1fcd87bbc6022d4` (`rgt`),
  KEY `idx_aae7a3ecb7ee41df8e892ac5c8b51382` (`level`),
  KEY `idx_094581687a7a3efb9f5cc996882957a7` (`elementId`),
  CONSTRAINT `structureelements_structureid_foreign` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dbdcbcd0b487505a5427d3df6618a2e7` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_160d96e7a09aaf63327041f080956b07` (`key`,`language`),
  KEY `idx_d0351728359d09068c582348fe52630b` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploadsessions`
--

DROP TABLE IF EXISTS `uploadsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `uploadsessions` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handler` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploader` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` bigint unsigned NOT NULL,
  `chunkSize` bigint unsigned NOT NULL DEFAULT '1',
  `parameters` json NOT NULL,
  `state` json NOT NULL,
  `result` json DEFAULT NULL,
  `expiresAt` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uploadsessions_expiresat_index` (`expiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploadsessions`
--

LOCK TABLES `uploadsessions` WRITE;
/*!40000 ALTER TABLE `uploadsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `uploadsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_38c14123f041ec833b23d81ea7a377cf` (`handle`),
  KEY `idx_757eba870996e09765b174141f2c8fa6` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_46c507d0bcc2fd8ba251aaaff5bbd14e` (`groupId`,`userId`),
  KEY `idx_1b55a521a70989ce61b00f171c33272d` (`userId`),
  CONSTRAINT `usergroups_users_groupid_foreign` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_179202557c981a10860c624913618a00` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_4947a65b534e5b8340405d5a333206ed` (`permissionId`,`groupId`),
  KEY `idx_3017b343133803040e4b44e21157e450` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupid_foreign` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionid_foreign` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_450a5792849b7209dc353b3cd80d7f2a` (`permissionId`,`userId`),
  KEY `idx_8dc057c349376943342015e55a8c15c5` (`userId`),
  CONSTRAINT `userpermissions_users_permissionid_foreign` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fullName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `unverifiedEmail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `rememberToken` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ff1b8eddb4e1dd4d55f011fa335b3812` (`active`),
  KEY `idx_28c5f12d433243cc132ac76d3760df6f` (`locked`),
  KEY `idx_4db362c19dc1488087bd9e4b9d7e3042` (`pending`),
  KEY `idx_a6c3f4989a3607d0c7e42cc6cc9feb47` (`suspended`),
  KEY `idx_5427c8655d5f1bf0317c8a64249f0dde` (`email`),
  KEY `idx_92672bf95f8a5543e3764d3d7aef8c78` (`username`),
  KEY `users_photoid_foreign` (`photoId`),
  KEY `users_affiliatedsiteid_foreign` (`affiliatedSiteId`),
  CONSTRAINT `users_affiliatedsiteid_foreign` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_id_foreign` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoid_foreign` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'hallo@knecht.works','$2y$12$FA0hJkFxZXKCgYZiNIjhguxw7IGGsOln9bPRzjKRrzay2hFOpq8uS','2026-10-07 11:25:53',NULL,NULL,NULL,NULL,NULL,1,NULL,0,'2026-10-07 04:36:01','uxrgqenovvbblaunrckutovderzaxnnmypfltfteyxftfjhijzlcndloihaa','2026-10-07 08:17:22','2026-10-07 04:36:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aab4cf998d2cdc5fb592b5519e5d0dd5` (`name`,`parentId`,`volumeId`),
  KEY `idx_fe1d114bc39924afc3816cc0208d44a6` (`parentId`),
  KEY `idx_a519ff53ab2406c1ef5745d089c66952` (`volumeId`),
  CONSTRAINT `volumefolders_parentid_foreign` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeid_foreign` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images','','2026-10-07 08:25:28','2026-10-07 08:25:28','01a11577-b3d5-73b5-94a1-7fab6ec9ecdd'),(2,NULL,NULL,'Temporary Uploads',NULL,'2026-10-07 04:25:53','2026-10-07 04:25:53','01a1161c-e115-70c0-ad02-1440cc722d31'),(3,2,NULL,'user_1','user_1/','2026-10-07 04:25:53','2026-10-07 04:25:53','01a1161c-e116-71b3-8bae-7056ffc8f2f3');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fs` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `subpath` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assetTransformer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titleTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8mb4_unicode_ci,
  `altTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text COLLATE utf8mb4_unicode_ci,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_847978ede931e5139ffec4b9493b325b` (`name`),
  KEY `idx_31b3c9b6e579d631bccf8a9bed072e95` (`handle`),
  KEY `idx_adb577778ab2b4091c81914b8ad6be4e` (`fieldLayoutId`),
  KEY `idx_36e110638bd55c49aaf035aa406a1e08` (`dateDeleted`),
  CONSTRAINT `volumes_fieldlayoutid_foreign` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,1,'Images','images','assets',1,'images',NULL,'site',NULL,'none',NULL,1,'2026-10-07 08:25:28','2026-10-07 08:25:28',NULL,'086104d4-cbc2-4ac3-aba8-706b10fb7576');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credential` text COLLATE utf8mb4_unicode_ci,
  `credentialName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `webauthn_userid_foreign` (`userId`),
  CONSTRAINT `webauthn_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_611d521da92ad852c077e9f50d2dd7a4` (`userId`),
  CONSTRAINT `widgets_userid_foreign` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'CraftCms\\Cms\\Dashboard\\Widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}','2026-10-07 04:25:53','2026-10-07 04:25:53','0'),(2,1,'CraftCms\\Cms\\Dashboard\\Widgets\\CraftSupport',2,NULL,'[]','2026-10-07 04:25:53','2026-10-07 04:25:53','0'),(3,1,'CraftCms\\Cms\\Dashboard\\Widgets\\Updates',3,NULL,'[]','2026-10-07 04:25:53','2026-10-07 04:25:53','0'),(4,1,'CraftCms\\Cms\\Dashboard\\Widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}','2026-10-07 04:25:53','2026-10-07 04:25:53','0');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflowruns`
--

DROP TABLE IF EXISTS `workflowruns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflowruns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `workflowId` int DEFAULT NULL,
  `draftId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `activityRootEventId` bigint unsigned NOT NULL,
  `currentStage` smallint unsigned NOT NULL DEFAULT '0',
  `currentStageResult` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ea2d74d47945cbef06c1856eaade517f` (`activityRootEventId`),
  KEY `idx_b0e3db5db109b45235b9f372747316a0` (`draftId`,`dateCreated`),
  KEY `idx_361a3df6b29982db76f27b628a2ff39e` (`draftId`,`status`),
  KEY `workflowruns_workflowid_foreign` (`workflowId`),
  KEY `workflowruns_authorid_foreign` (`authorId`),
  CONSTRAINT `workflowruns_activityrooteventid_foreign` FOREIGN KEY (`activityRootEventId`) REFERENCES `activityevents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `workflowruns_authorid_foreign` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `workflowruns_workflowid_foreign` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflowruns`
--

LOCK TABLES `workflowruns` WRITE;
/*!40000 ALTER TABLE `workflowruns` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflowruns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows`
--

DROP TABLE IF EXISTS `workflows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stages` json NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workflows_uid_unique` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows`
--

LOCK TABLES `workflows` WRITE;
/*!40000 ALTER TABLE `workflows` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-07 13:36:11
